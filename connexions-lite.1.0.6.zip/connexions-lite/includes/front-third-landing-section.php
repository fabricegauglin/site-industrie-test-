<div id="section3" class="landing-section skt-section skt-default-page">
	<div class="container" >
		<div class="row-fluid">
			<div class="span12">
				<div class="title custicon"><p class="landing-section-heading"><?php echo wp_kses_post( get_theme_mod('connexions_lite_rat_third_section_title', __('OUR SKILLS', 'connexions-lite') ) ); ?></p><div class="title-border"><i class="fa fa-gift"></i></div></div>
				<div class="landing-page-content">
					<?php echo do_shortcode( wp_kses_post( get_theme_mod('connexions_lite_rat_third_section_content', '<div class="text-justify">'.__('Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'connexions-lite').'</div>' ) ) ); ?>
				</div>
			</div>
		</div>
	</div>
</div>