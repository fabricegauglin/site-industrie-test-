<?php
/********************************************
 FRAME WORK CODE STARTS HERE
*********************************************/
require_once(get_template_directory().'/SketchBoard/functions/sketch-enqueue.php');                       // ENQUEUE CSS SCRIPTS
require_once(get_template_directory().'/SketchBoard/functions/sketch-functions.php');                     // PAGINATION, EXCERPT CONTROL ETC..
require_once(get_template_directory().'/SketchBoard/functions/sketch-breadcrumb.php');                    // CUSTOM POST TYPES INCLUDES
?>