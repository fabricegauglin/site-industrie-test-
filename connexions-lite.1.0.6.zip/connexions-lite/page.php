<?php
/**
 * The Template for displaying all single pages.
 * @package WordPress
 * @SketchThemes
 */

get_header(); 

get_template_part('includes/page','content');

get_footer();

?>